import logging
import random
import requests

from lib.config import get_config
from lib.paths import plugin_download_path

logger = logging.getLogger(f"wordpress-plugin-grep.{__name__}")


def get_plugin_info(page=1):
    config = get_config()
    wordpress_api_hostname = config.get('api').get('hostname')
    wordpress_api_querystring = config.get('api').get('querystring')
    url = f"https://{wordpress_api_hostname}/{wordpress_api_querystring}{page}"
    logger.debug("Using URL: %s", url)
    try:
        request = requests.get(url)
    except requests.RequestException as failed_request:
        raise failed_request
    data = request.json()
    plugins = data['plugins']
    return plugins


def get_plugin_download_links():
    config = get_config()
    plugins_ = []
    
    # Generate a list of pages (adjust the total number of pages as needed)
    total_pages = 100  # You can adjust this number to the actual number of pages available
    pages = list(range(1, total_pages + 1))
    
    # Shuffle the pages to randomize the download pattern
    random.shuffle(pages)
    
    logger.info("Getting plugins with >= %s active installs.", config.get('plugins').get('active_install'))
    
    # Traverse the shuffled list of pages
    for page in pages:
        plugins = get_plugin_info(page)
        
        # Check if the top plugin on the page meets the active installs requirement
        if plugins[0]['active_installs'] >= config.get('plugins').get('active_install'):
            for plugin in plugins:
                plugins_.append(plugin['download_link'])
            logger.info("Collected %d download links from page %d.", len(plugins_), page)
        else:
            logger.info("Stopping: Page %d contains plugins with fewer installs than required.", page)
            break  # Stop if plugins no longer meet the threshold
    
    return plugins_


def download_plugins(plugins_to_download):
    logger.info("Downloading %d plugins.", len(plugins_to_download))
    for plugin in plugins_to_download:
        r = requests.get(plugin)
        plugin_name = plugin.split('/')[-1]
        plugin_path = plugin_download_path(plugin_name)
        logger.info("Writing plugin to %s", plugin_path)
        with open(plugin_path, 'wb') as plugin_file:
            plugin_file.write(r.content)


def get_plugins():
    plugins_to_download = get_plugin_download_links()
    download_plugins(plugins_to_download)
